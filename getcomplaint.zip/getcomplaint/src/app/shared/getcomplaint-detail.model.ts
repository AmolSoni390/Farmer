export class GetcomplaintDetail {
    complaintsId:number | undefined;
    complaintMessage:string='';
    complaintStatus:string=''
}
