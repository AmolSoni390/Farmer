import { Injectable } from '@angular/core';
import {GetcomplaintDetail} from './getcomplaint-detail.model';
import { HttpClient } from "@angular/common/http"
@Injectable({
  providedIn: 'root'
})
export class GetcomplaintDetailService {

  formData:GetcomplaintDetail=new GetcomplaintDetail();
readonly baseURL='http://localhost:33402/api/Farmer/getComplaints';
list:GetcomplaintDetail[] | undefined;

  constructor(private http: HttpClient) { }
  
  refreshList() {
    this.http.get(this.baseURL)
      .toPromise()
      .then(res =>this.list = res as GetcomplaintDetail[]);
  }
}
