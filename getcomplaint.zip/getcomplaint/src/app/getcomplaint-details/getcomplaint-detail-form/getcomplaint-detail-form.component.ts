import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { GetcomplaintDetailService } from './../../shared/getcomplaint-detail.service';
import { GetcomplaintDetail } from 'src/app/shared/getcomplaint-detail.model';

@Component({
  selector: 'app-getcomplaint-detail-form',
  templateUrl: './getcomplaint-detail-form.component.html',
  styles: [
  ]
})
export class GetcomplaintDetailFormComponent implements OnInit {

  constructor(public service: GetcomplaintDetailService) { }

  ngOnInit(): void {
  }
  resetForm(form: NgForm) {
    form.form.reset();
    this.service.formData = new GetcomplaintDetail();
  }

}
