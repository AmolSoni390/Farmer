import { Component, OnInit } from '@angular/core';
import { GetcomplaintDetailService } from '././../shared/getcomplaint-detail.service';

@Component({
  selector: 'app-getcomplaint-details',
  templateUrl: './getcomplaint-details.component.html',
  styles: [
  ]
})
export class GetcomplaintDetailsComponent implements OnInit {

  constructor(public service: GetcomplaintDetailService) { }
  populateForm(selectedRecord: any) {
    this.service.formData = Object.assign({}, selectedRecord);
  }
  ngOnInit(){
    this.service.refreshList();
  }

}
